# [Stuff Worth Sharing #1] How to solder SMD components

This series is intended to share the interesting and useful stuff I’ve collected from the internet.

---

I often get stuck and make mistakes when trying to solder small components. This video is really helpful—it shares great tips for soldering small components more effectively.

<iframe width="560" height="315" src="[https://www.youtube.com/embed/fYInlAmPnGo?si=RMek84LLoLEMEiZP](https://www.youtube.com/embed/fYInlAmPnGo?si=RMek84LLoLEMEiZP)" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>

If you find the video helpful, consider liking and sharing to support the author!